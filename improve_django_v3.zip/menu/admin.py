from django.contrib import admin
from .models import Menu, Item, Ingredient

admin.site.register(Menu)
admin.site.register(Item)
admin.site.register(Ingredient)